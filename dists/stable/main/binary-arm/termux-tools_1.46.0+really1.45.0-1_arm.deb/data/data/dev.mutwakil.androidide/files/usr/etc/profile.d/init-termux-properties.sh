if [ ! -f /data/data/dev.mutwakil.androidide/files/home/.config/termux/termux.properties ] && [ ! -e /data/data/dev.mutwakil.androidide/files/home/.termux/termux.properties ]; then
	mkdir -p /data/data/dev.mutwakil.androidide/files/home/.termux
	cp /data/data/dev.mutwakil.androidide/files/usr/share/examples/termux/termux.properties /data/data/dev.mutwakil.androidide/files/home/.termux/
fi
