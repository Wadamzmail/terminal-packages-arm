# -*- tcl -*-
# Tcl package index file, version ???
#
package ifneeded sqlite3 3.53.3 \
    [list load [file join $dir libsqlite3.53.3.so] Sqlite3]

